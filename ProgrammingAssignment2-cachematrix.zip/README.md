# Programming Assignment 2 — Caching the Inverse of a Matrix

Files:
- `cachematrix.R` — Implementation of `makeCacheMatrix()` and `cacheSolve()`.

## Quick test in R
```r
source("cachematrix.R")
A <- matrix(c(2, 0, 0, 0.5), 2, 2)
cm <- makeCacheMatrix(A)

cacheSolve(cm)              # compute
cacheSolve(cm)              # should print "getting cached inverse"

all.equal(diag(2), A %*% cacheSolve(cm))  # should be TRUE
```
