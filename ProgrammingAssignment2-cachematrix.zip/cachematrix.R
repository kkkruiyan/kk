## Programming Assignment 2: Caching the Inverse of a Matrix
## cachematrix.R

## makeCacheMatrix: 创建可缓存逆矩阵的“特殊矩阵”对象
makeCacheMatrix <- function(x = matrix()) {
  inv <- NULL                     # 用于缓存的逆矩阵

  set <- function(y) {            # 赋新矩阵时，清空缓存
    x <<- y
    inv <<- NULL
  }
  get <- function() x             # 取矩阵

  setinv <- function(i) inv <<- i # 缓存逆矩阵
  getinv <- function() inv        # 取缓存

  list(set = set, get = get, setinv = setinv, getinv = getinv)
}

## cacheSolve: 计算并缓存逆矩阵；若已缓存且矩阵未变，则直接返回缓存
cacheSolve <- function(x, ...) {
  inv <- x$getinv()
  if (!is.null(inv)) {
    message("getting cached inverse")
    return(inv)
  }
  mat <- x$get()

  ## （可选）基本健壮性检查：方阵与可逆性
  if (!is.matrix(mat)) stop("x$get() 必须返回矩阵")
  if (nrow(mat) != ncol(mat)) stop("矩阵不是方阵，无法求逆")

  inv <- solve(mat, ...)   # 计算逆
  x$setinv(inv)            # 写入缓存
  inv
}
